import { execSync } from 'child_process';

try {
  console.log('Initializing git...');
  execSync('git init', { stdio: 'inherit' });
  
  console.log('Configuring git...');
  execSync('git config user.email "hani.brahim130@gmail.com"', { stdio: 'inherit' });
  execSync('git config user.name "Hani Brahim"', { stdio: 'inherit' });
  
  console.log('Adding files...');
  execSync('git add .', { stdio: 'inherit' });
  
  console.log('Committing...');
  try {
    execSync('git commit -m "Initial commit: BundlyPlus UI"', { stdio: 'inherit' });
  } catch (e) {
    console.log('Nothing to commit or commit failed, continuing...');
  }
  
  console.log('Setting branch...');
  execSync('git branch -M main', { stdio: 'inherit' });
  
  console.log('Setting remote...');
  try {
    execSync('git remote remove origin', { stdio: 'ignore' });
  } catch (e) {}
  
  const repoUrl = 'https://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@github.com/hanibrahim130-boop/bundly-plus-workspace.git';
  execSync(`git remote add origin ${repoUrl}`, { stdio: 'inherit' });
  
  console.log('Pushing to GitHub...');
  execSync('git push -u origin main --force', { stdio: 'inherit' });
  
  console.log('Push successful!');
} catch (error) {
  console.error('Error during git operations:', error);
  process.exit(1);
}
