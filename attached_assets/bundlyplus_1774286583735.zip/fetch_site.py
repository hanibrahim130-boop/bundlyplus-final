import urllib.request
import urllib.error
import json
import base64
import os

def request_json(url, headers):
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req) as response:
            return json.loads(response.read().decode())
    except urllib.error.URLError as e:
        print(f"Error fetching {url}: {e}")
        if hasattr(e, 'read'):
            print(e.read().decode())
        return None

def main():
    gh_user = "hanibrahim130-boop"
    gh_repo = "bundly-plus-workspace"
    gh_token = "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"
    vercel_token = "vcp_44R8GS4kuoppawB4Q0YMDZGBWwmyzfEtBgNgfMBe0dJEICzs6T0E2XJK"

    gh_headers = {
        "Authorization": f"Bearer {gh_token}",
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "Python-Script",
        "X-GitHub-Api-Version": "2022-11-28"
    }

    vercel_headers = {
        "Authorization": f"Bearer {vercel_token}",
        "Content-Type": "application/json"
    }

    print("--- Fetching Vercel Info ---")
    vercel_url = "https://api.vercel.com/v9/projects"
    vercel_data = request_json(vercel_url, vercel_headers)
    
    if vercel_data and "projects" in vercel_data:
        found = False
        for proj in vercel_data["projects"]:
            link = proj.get("link", {})
            if link and link.get("repo") == gh_repo:
                print(f"Project Name: {proj.get('name')}")
                print(f"Framework: {proj.get('framework')}")
                print(f"Node Version: {proj.get('nodeVersion')}")
                found = True
                break
        if not found:
            print("Project not found in Vercel or repo mismatch.")
    else:
        print("Could not fetch Vercel projects.")

    print(f"\n--- Fetching GitHub Tree for {gh_user}/{gh_repo} ---")
    tree_url = f"https://api.github.com/repos/{gh_user}/{gh_repo}/git/trees/main?recursive=1"
    tree_data = request_json(tree_url, gh_headers)

    if not tree_data or "tree" not in tree_data:
        print("Failed to fetch repository tree.")
        return

    downloaded_files = []
    main_entry = None

    print("\n--- Downloading files ---")
    for item in tree_data["tree"]:
        if item["type"] == "blob":
            path = item["path"]
            if "node_modules" in path or ".git" in path:
                continue
                
            file_url = item["url"]
            file_data = request_json(file_url, gh_headers)
            
            if file_data and "content" in file_data:
                content = base64.b64decode(file_data["content"])
                
                os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
                
                with open(path, "wb") as f:
                    f.write(content)
                
                downloaded_files.append(path)
                print(f"Saved: {path}")

                if path in ["index.html", "src/App.tsx", "src/main.tsx", "pages/index.tsx", "app/page.tsx", "src/index.js"]:
                    if not main_entry or path == "src/App.tsx":
                        main_entry = path

    print("\n--- Summary ---")
    print(f"Total files downloaded: {len(downloaded_files)}")
    
    if main_entry:
        print(f"\nMain entry file identified: {main_entry}")
        try:
            with open(main_entry, "r", encoding="utf-8") as f:
                print(f"--- Content of {main_entry} (first 15 lines) ---")
                lines = f.readlines()
                print("".join(lines[:15]))
        except Exception as e:
            print(f"Could not read {main_entry}: {e}")
    else:
        print("\nCould not identify a standard main entry file.")

if __name__ == "__main__":
    main()
