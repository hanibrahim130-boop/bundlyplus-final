import { GoogleGenAI } from "@google/genai";

// Initialize with platform-provided key
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

export async function generateCompanyLogo(companyName: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            text: `Official logo of the company "${companyName}". Minimalist, flat vector design, suitable for dark mode UI, high contrast, high quality, professional branding.`,
          },
        ],
      },
    });
    
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        const base64EncodeString: string = part.inlineData.data;
        return `data:image/png;base64,${base64EncodeString}`;
      }
    }
  } catch (error) {
    console.error("Error generating logo:", error);
  }
  return null;
}
