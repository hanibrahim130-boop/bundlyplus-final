import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, ShoppingCart, Phone, ChevronLeft, ChevronRight, ChevronDown, Facebook, Twitter, Youtube, Check, Cloud, PenTool, Layout, Database, Zap, Monitor, Cpu, Globe, Shield, Link as LinkIcon, Headphones, Home, Package, Layers, Repeat, Plus, Minus, Trash2, ArrowLeft, Loader2 } from 'lucide-react';
import productsData from './data/products.json';
import settingsData from './data/settings.json';
import { generateCompanyLogo } from './services/geminiService';
import bundlesData from './data/bundles.json';

const siteSettings = settingsData.find(s => s.id === 'site') || {};

type Product = typeof productsData[0];
type Bundle = typeof bundlesData[0];
type CartItem = (Product | Bundle) & { quantity: number; isBundle?: boolean };

const Background = () => (
  <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none bg-[#0a0a0f]">
    {/* Abstract mesh gradients */}
    <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-purple-600/20 rounded-full blur-[120px]" />
    <div className="absolute top-[20%] right-[-10%] w-[40%] h-[60%] bg-orange-500/10 rounded-full blur-[150px]" />
    <div className="absolute bottom-[-10%] left-[10%] w-[60%] h-[50%] bg-blue-600/10 rounded-full blur-[150px]" />
    
    {/* Grid pattern overlay */}
    <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAwIDEwIEwgNDAgMTAgTSAxMCAwIEwgMTAgNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsIDI1NSwgMjU1LCAwLjAzKSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-50 mix-blend-overlay" />
  </div>
);

const Navbar = ({ cartCount, setCurrentView }: { cartCount: number, setCurrentView: (v: string) => void }) => (
  <nav className="fixed top-6 left-1/2 -translate-x-1/2 w-[90%] max-w-6xl z-50 bg-white/5 backdrop-blur-md border border-white/10 rounded-full px-6 py-3 flex justify-between items-center">
    <div className="text-xl font-bold text-white cursor-pointer" onClick={() => setCurrentView('home')}>{siteSettings.site_name || 'BundlyPlus'}</div>
    <div className="hidden md:flex space-x-8 text-sm text-white/70">
      <button onClick={() => setCurrentView('home')} className="hover:text-white transition-colors">Home</button>
      <button onClick={() => setCurrentView('products')} className="hover:text-white transition-colors">Products</button>
      <button onClick={() => setCurrentView('bundles')} className="hover:text-white transition-colors">Bundles</button>
    </div>
    <div className="flex space-x-3">
      <button onClick={() => setCurrentView('cart')} className="relative flex items-center space-x-2 px-4 py-2 rounded-full border border-white/20 text-white/80 hover:bg-white/10 text-sm transition-colors">
        <ShoppingCart size={16} />
        <span className="hidden sm:inline">Cart</span>
        {cartCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-cyan-500 text-black text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
            {cartCount}
          </span>
        )}
      </button>
      <button className="flex items-center space-x-2 px-4 py-2 rounded-full border border-white/20 text-white/80 hover:bg-white/10 text-sm transition-colors">
        <Phone size={16} />
        <span className="hidden sm:inline">Contact Us</span>
      </button>
    </div>
  </nav>
);

const Hero = () => (
  <section className="relative z-10 pt-40 pb-20 px-6 max-w-7xl mx-auto flex flex-col lg:flex-row items-center">
    <div className="lg:w-1/2 space-y-8">
      <h1 className="text-5xl md:text-7xl font-serif text-white leading-tight whitespace-pre-line">
        {siteSettings.hero_title || 'Simplify Your\nDigital Life'}
      </h1>
      <p className="text-lg text-white/60 max-w-lg leading-relaxed">
        {siteSettings.hero_subtitle || 'BundlyPlus is the ultimate service aggregator, bringing all your essential digital tools into one seamless experience.'}
      </p>
      <div className="flex flex-wrap gap-4">
        <button className="px-8 py-3 rounded-full bg-gradient-to-r from-orange-200 to-orange-400 text-black font-medium hover:opacity-90 transition-opacity shadow-[0_0_20px_rgba(251,146,60,0.3)]">
          {siteSettings.hero_cta || 'Explore Bundles'}
        </button>
        <button className="px-8 py-3 rounded-full border border-white/20 text-white hover:bg-white/10 transition-colors">
          How it Works
        </button>
      </div>
    </div>
    <div className="lg:w-1/2 mt-16 lg:mt-0 relative h-[500px] w-full flex justify-center items-center perspective-1000">
      {/* Simulated 3D Glass Widgets */}
      <motion.div 
        animate={{ 
          y: [-15, 15, -15], 
          rotateX: [5, -5, 5], 
          rotateY: [-5, 5, -5],
          boxShadow: [
            "0 25px 50px -12px rgba(0, 0, 0, 0.5), inset 0 0 0 1px rgba(255, 255, 255, 0.1)",
            "0 35px 60px -15px rgba(0, 0, 0, 0.6), inset 0 0 20px 2px rgba(255, 255, 255, 0.15)",
            "0 25px 50px -12px rgba(0, 0, 0, 0.5), inset 0 0 0 1px rgba(255, 255, 255, 0.1)"
          ]
        }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        className="absolute w-64 h-64 bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl flex flex-col p-4 z-20"
      >
         <div className="w-full h-1/2 bg-gradient-to-br from-orange-400/20 to-purple-500/20 rounded-2xl mb-4 flex items-center justify-center">
            <Cloud className="w-16 h-16 text-white/80" />
         </div>
         <div className="flex gap-2">
            <div className="w-1/2 h-12 bg-white/5 rounded-xl"></div>
            <div className="w-1/2 h-12 bg-white/5 rounded-xl"></div>
         </div>
      </motion.div>
      
      <motion.div 
        animate={{ 
          y: [10, -20, 10], 
          x: [0, 10, 0],
          rotateX: [-5, 10, -5], 
          rotateY: [5, -10, 5],
          scale: [1, 1.05, 1],
          boxShadow: [
            "0 20px 40px -10px rgba(255, 100, 200, 0.15), inset 0 0 0 1px rgba(255, 255, 255, 0.1)",
            "0 30px 50px -12px rgba(255, 100, 200, 0.25), inset 0 0 15px 1px rgba(255, 255, 255, 0.2)",
            "0 20px 40px -10px rgba(255, 100, 200, 0.15), inset 0 0 0 1px rgba(255, 255, 255, 0.1)"
          ]
        }}
        transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 1 }}
        className="absolute -top-10 right-10 md:right-20 w-32 h-32 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl flex items-center justify-center z-10"
      >
        <div className="text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-pink-500 to-orange-400">A</div>
      </motion.div>

      <motion.div 
        animate={{ 
          y: [-15, 10, -15],
          x: [-5, 5, -5],
          rotateZ: [-2, 2, -2],
          scale: [0.95, 1, 0.95],
          boxShadow: [
            "0 15px 35px -10px rgba(100, 200, 255, 0.15), inset 0 0 0 1px rgba(255, 255, 255, 0.1)",
            "0 25px 45px -12px rgba(100, 200, 255, 0.25), inset 0 0 15px 1px rgba(255, 255, 255, 0.2)",
            "0 15px 35px -10px rgba(100, 200, 255, 0.15), inset 0 0 0 1px rgba(255, 255, 255, 0.1)"
          ]
        }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 2 }}
        className="absolute bottom-10 left-10 md:left-20 w-40 h-24 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-4 flex flex-col justify-between z-30"
      >
        <div className="w-full h-2 bg-white/20 rounded-full"></div>
        <div className="w-3/4 h-2 bg-white/20 rounded-full"></div>
        <div className="w-1/2 h-2 bg-white/20 rounded-full"></div>
      </motion.div>
    </div>
  </section>
);

const WhyChooseUs = () => {
  const features = [
    {
      icon: <Shield className="w-8 h-8 text-cyan-400 drop-shadow-[0_0_10px_rgba(34,211,238,0.8)]" />,
      title: "UNMATCHED SECURITY",
      desc: "State-of-the-art encryption to keep your data safe and secure."
    },
    {
      icon: <Zap className="w-8 h-8 text-yellow-400 drop-shadow-[0_0_10px_rgba(250,204,21,0.8)]" />,
      title: "BLAZING SPEED",
      desc: "Experience rapid performance and minimal load times for all tools."
    },
    {
      icon: <LinkIcon className="w-8 h-8 text-green-400 drop-shadow-[0_0_10px_rgba(74,222,128,0.8)]" />,
      title: "SEAMLESS INTEGRATION",
      desc: "Effortlessly connect all your essential services in one place."
    },
    {
      icon: <Headphones className="w-8 h-8 text-pink-400 drop-shadow-[0_0_10px_rgba(244,114,182,0.8)]" />,
      title: "24/7 SUPPORT",
      desc: "Our dedicated team is always here to help you around the clock."
    }
  ];

  return (
    <section className="relative z-10 py-20 px-6 max-w-6xl mx-auto flex flex-col md:flex-row gap-12 items-center">
      <div className="md:w-1/3 text-left">
        <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif text-white uppercase leading-tight tracking-wide">
          Why<br />Choose<br />Us
        </h2>
      </div>
      
      <div className="md:w-2/3 grid grid-cols-1 sm:grid-cols-2 gap-4">
        {features.map((feature, i) => (
          <div key={i} className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 flex items-start space-x-5 hover:bg-white/10 transition-colors">
            <div className="flex-shrink-0 mt-1">
              {feature.icon}
            </div>
            <div>
              <h3 className="text-white font-medium text-sm tracking-wider mb-2">{feature.title}</h3>
              <p className="text-white/60 text-xs leading-relaxed">
                {feature.desc}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

const Pricing = ({ addToCart }: { addToCart: (p: Product) => void }) => {
  const featuredProducts = productsData.filter(p => p.featured).slice(0, 3);
  
  return (
    <section className="relative z-10 py-20 px-6 max-w-6xl mx-auto flex flex-col items-center">
      <h2 className="text-xl md:text-2xl font-serif text-white uppercase tracking-widest mb-16 text-center">Featured Products</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full">
        {featuredProducts.map((product, index) => {
          const isPopular = index === 1; // Highlight the middle one
          return (
            <div 
              key={product.id} 
              className={`bg-white/5 backdrop-blur-md border ${isPopular ? 'border-cyan-400/50 shadow-[0_0_30px_rgba(34,211,238,0.15)] transform md:-translate-y-4' : 'border-white/10'} rounded-3xl p-8 flex flex-col items-center text-center relative`}
            >
              {isPopular && <div className="absolute inset-0 rounded-3xl border-2 border-cyan-400/30 pointer-events-none" />}
              
              <div className="w-full h-32 mb-6 rounded-2xl overflow-hidden bg-white/5 relative">
                <img 
                  src={product.image_url || `https://picsum.photos/seed/${product.id}/400/300`} 
                  alt={product.name}
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              <h3 className={`${isPopular ? 'text-cyan-400' : 'text-white/70'} uppercase tracking-widest text-sm font-medium mb-2`}>{product.name}</h3>
              <p className="text-white/50 text-xs mb-4 h-10">{product.description}</p>
              <div className="text-4xl text-white font-serif mb-8">${product.price}<span className="text-lg text-white/50 font-sans">/{product.duration?.toLowerCase().replace('_', ' ') || 'month'}</span></div>
              <ul className="space-y-4 mb-10 text-sm text-white/70 text-left w-full flex-grow">
                {product.features.map((feature, i) => (
                  <li key={i} className="flex items-center"><Check size={16} className={`mr-3 ${isPopular ? 'text-cyan-400/70' : 'text-white/50'}`} /> {feature}</li>
                ))}
              </ul>
              <button 
                onClick={() => addToCart(product)}
                className={`w-full py-3 rounded-full border ${isPopular ? 'border-cyan-400/50 text-white hover:bg-cyan-400/20' : 'border-white/20 text-white/80 hover:bg-white/10'} text-xs font-medium uppercase tracking-widest transition-colors mt-auto block text-center`}
              >
                Add to Cart
              </button>
            </div>
          );
        })}
      </div>
    </section>
  );
};

const Testimonials = () => (
  <section className="relative z-10 py-20 px-6 max-w-6xl mx-auto flex flex-col items-center">
    <h2 className="text-xl md:text-2xl font-serif text-white uppercase tracking-widest mb-12 text-center">Trusted by Thousands</h2>
    
    <div className="flex items-center w-full gap-4">
      <button className="hidden md:flex w-10 h-10 rounded-full bg-white/5 border border-white/10 items-center justify-center text-white/50 hover:bg-white/10 hover:text-white transition-colors flex-shrink-0">
        <ChevronLeft size={20} />
      </button>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full overflow-hidden">
        {[
          { quote: "The stack is at real-world ne-venns ucare is Canbat tielivatike secn rock phoe.", name: "Amarib, Mus", color: "from-orange-400 to-pink-500" },
          { quote: "I'm your rocket teem you for choofeg dars and bondening then loooded and fiemmes cenecotes.", name: "Nies Milleh", color: "from-cyan-400 to-blue-500" },
          { quote: "Tooroonstion endse inatiam pessed mg taene setes er npisa a builting benet of sassee.", name: "Merlan Erehgard", color: "from-purple-400 to-pink-500" }
        ].map((t, i) => (
          <div key={i} className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 flex flex-col">
            <p className="text-white/70 text-sm leading-relaxed mb-6 flex-grow">
              "{t.quote}"
            </p>
            <div className="flex items-center justify-between">
              <span className="text-white font-medium text-sm">{t.name}</span>
              <div className={`w-8 h-8 rounded-full bg-gradient-to-tr ${t.color}`} />
            </div>
          </div>
        ))}
      </div>

      <button className="hidden md:flex w-10 h-10 rounded-full bg-white/5 border border-white/10 items-center justify-center text-white/50 hover:bg-white/10 hover:text-white transition-colors flex-shrink-0">
        <ChevronRight size={20} />
      </button>
    </div>
  </section>
);

const FAQ = () => {
  const faqs = [
    "What are our own tokens?",
    "Can you have any questions?",
    "Can I snecmsny other questions?",
    "How many w:class questions FAQ"
  ];

  return (
    <section className="relative z-10 py-20 px-6 max-w-5xl mx-auto flex flex-col md:flex-row gap-12 items-start">
      <div className="md:w-1/3 text-center md:text-left">
        <h2 className="text-xl font-serif text-white uppercase tracking-widest mb-4">Got Questions?</h2>
        <h1 className="text-6xl md:text-7xl font-serif text-white">FAQ</h1>
      </div>
      
      <div className="md:w-2/3 w-full space-y-3">
        {faqs.map((faq, i) => (
          <div key={i} className="bg-white/5 border border-white/10 rounded-xl p-5 flex justify-between items-center cursor-pointer hover:bg-white/10 transition-colors">
            <span className="text-white/80 text-sm">{faq}</span>
            <ChevronDown size={16} className="text-white/50" />
          </div>
        ))}
      </div>
    </section>
  );
};

const getDomain = (name: string): string | null => {
  const mapping: { [key: string]: string } = {
    'Perplexity AI': 'perplexity.ai',
    'Figma Professional': 'figma.com',
    'Watchit': 'watchit.com',
    'Vercel Pro': 'vercel.com',
    'Microsoft 365 Personal': 'microsoft.com',
    'Notion AI': 'notion.so',
    'OSN+': 'osn.com',
    'Adobe Creative Cloud': 'adobe.com',
    'Loom Pro': 'loom.com',
    'ChatGPT Plus': 'openai.com',
    'YouTube Premium': 'youtube.com',
    'Apple TV+': 'apple.com',
    'Canva Pro': 'canva.com',
    'Retool Studio': 'retool.com',
    'Google Workspace Business Starter': 'workspace.google.com',
    'Disney+': 'disneyplus.com',
    'Max (HBO Max)': 'max.com',
    'Slack Professional': 'slack.com',
    'Midjourney': 'midjourney.com',
    'Hulu': 'hulu.com',
    'Synthesia': 'synthesia.io',
    'Paramount+': 'paramountplus.com',
    'Cursor IDE Pro': 'cursor.com',
    'Linear Pro': 'linear.app',
    'Runway AI': 'runwayml.com',
    'StarzPlay Arabia': 'starzplay.com',
    'Shahid VIP': 'shahid.mbc.net',
    'Google Gemini Advanced': 'gemini.google.com',
    'Weyyak': 'weyyak.com',
    'Nintendo Switch Online': 'nintendo.com',
    'Jasper AI': 'jasper.ai',
    'DAZN': 'dazn.com',
    'Tidal HiFi': 'tidal.com',
    'GitHub Copilot Pro': 'github.com',
    'Framer Pro': 'framer.com',
    'Roblox – 1000 Robux': 'roblox.com',
    'ExpressVPN': 'expressvpn.com',
    'Funimation Premium': 'funimation.com',
    'Netflix Premium – Private Account': 'netflix.com',
    'Amazon Prime Video': 'amazon.com',
    'Spotify Premium': 'spotify.com',
    'Microsoft Copilot Pro': 'microsoft.com',
    'Duolingo Plus': 'duolingo.com',
    'Writesonic': 'writesonic.com',
    'Crunchyroll Mega Fan': 'crunchyroll.com',
    'PlayStation Plus Essential': 'playstation.com',
    'Copy.ai': 'copy.ai',
    'Grammarly Premium': 'grammarly.com',
    'Descript': 'descript.com',
  };
  
  return mapping[name] || null;
};

const getInitials = (name: string) => {
  return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
};

const ProductsView = ({ addToCart }: { addToCart: (p: Product) => void }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [products, setProducts] = useState(productsData);
  const [generating, setGenerating] = useState<string | null>(null);

  const handleGenerateLogo = async (product: Product) => {
    setGenerating(product.id);
    const logoUrl = await generateCompanyLogo(product.name);
    if (logoUrl) {
      setProducts(prev => prev.map(p => p.id === product.id ? { ...p, image_url: logoUrl } : p));
    }
    setGenerating(null);
  };

  const categories = ['All', ...Array.from(new Set(products.map(p => p.category).filter(Boolean)))];

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          product.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <section className="relative z-10 pt-10 pb-10 px-6 max-w-6xl mx-auto flex flex-col items-center">
      <h2 className="text-3xl md:text-4xl font-serif text-white uppercase tracking-widest mb-8 text-center">All Products</h2>
      
      <div className="w-full max-w-4xl mb-12 space-y-6">
        <div className="relative">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-white/50" size={20} />
          <input 
            type="text" 
            placeholder="Search products..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-full py-4 pl-14 pr-6 text-white placeholder:text-white/30 focus:outline-none focus:border-cyan-400/50 transition-colors"
          />
        </div>
        
        <div className="flex flex-wrap justify-center gap-2">
          {categories.map(category => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full text-xs font-medium uppercase tracking-wider transition-colors ${
                selectedCategory === category 
                  ? 'bg-cyan-500 text-black' 
                  : 'bg-white/5 text-white/70 border border-white/10 hover:bg-white/10 hover:text-white'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 w-full items-stretch">
        {filteredProducts.length > 0 ? (
          filteredProducts.map((product, index) => {
            return (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                key={product.id} 
                className="bg-[#0A0A0A]/80 backdrop-blur-md border border-white/10 rounded-2xl p-6 flex flex-col items-center text-center relative hover:border-white/20 transition-colors h-full"
              >
                {product.category && (
                  <span className="absolute top-4 right-4 bg-white/10 text-white/90 text-[10px] uppercase tracking-wider px-2 py-1 rounded-md z-10 border border-white/5">
                    {product.category}
                  </span>
                )}
                
                <div className="w-14 h-14 mb-5 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center p-2.5 backdrop-blur-sm relative group shrink-0 mt-2">
                  {product.image_url ? (
                    <img
                      src={product.image_url}
                      className="w-full h-full object-contain rounded-lg"
                      alt={product.name}
                    />
                  ) : getDomain(product.name) ? (
                    <img
                      src={`https://logo.clearbit.com/${getDomain(product.name)}`}
                      className="w-full h-full object-contain rounded-lg"
                      alt={product.name}
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                        e.currentTarget.parentElement!.innerHTML = `<span style="font-size: 16px; font-weight: 500; color: #fff; letter-spacing: 1px;">${getInitials(product.name)}</span>`;
                      }}
                    />
                  ) : (
                    <span style={{ fontSize: '16px', fontWeight: 500, color: '#fff', letterSpacing: '1px' }}>{getInitials(product.name)}</span>
                  )}
                  <button 
                    onClick={() => handleGenerateLogo(product)}
                    disabled={generating === product.id}
                    className="absolute inset-0 bg-black/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-white rounded-xl"
                    title="Regenerate Logo"
                  >
                    {generating === product.id ? <Loader2 className="animate-spin w-4 h-4" /> : <Repeat className="w-4 h-4" />}
                  </button>
                </div>

                <h3 className="text-white text-base font-medium mb-2">{product.name}</h3>
                <p className="text-[#888888] text-sm mb-6 line-clamp-2 min-h-[40px]">{product.description}</p>
                
                <div className="mt-auto w-full flex flex-col items-center">
                  <div className="text-xl text-white font-medium mb-6">
                    ${product.price}
                    <span className="text-xs text-[#888888] font-normal ml-1">/{product.duration?.toLowerCase().replace('_', ' ') || 'month'}</span>
                  </div>
                  <button 
                    onClick={() => addToCart(product)}
                    className="w-full py-2.5 rounded-xl bg-white text-black hover:bg-gray-200 text-sm font-medium transition-colors"
                  >
                    Add to Cart
                  </button>
                </div>
              </motion.div>
            );
          })
        ) : (
          <div className="col-span-full text-center py-20 text-white/50">
            No products found matching your criteria.
          </div>
        )}
      </div>
    </section>
  );
};

const BottomNav = ({ currentView, setCurrentView, cartCount }: { currentView: string, setCurrentView: (v: string) => void, cartCount: number }) => {
  const navItems = [
    { id: 'home', icon: <Home size={20} />, label: 'Home' },
    { id: 'products', icon: <Package size={20} />, label: 'Products' },
    { id: 'bundles', icon: <Layers size={20} />, label: 'Bundles' },
    { id: 'subscriptions', icon: <Repeat size={20} />, label: 'Subs' },
    { id: 'cart', icon: <ShoppingCart size={20} />, label: 'Cart', badge: cartCount },
  ];

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[95%] max-w-md z-50 bg-[#1a1a24]/90 backdrop-blur-xl border border-white/10 rounded-full px-2 py-2 flex justify-between items-center shadow-2xl">
      {navItems.map(item => {
        const isActive = currentView === item.id;
        return (
          <button 
            key={item.id}
            onClick={() => setCurrentView(item.id)}
            className={`relative flex flex-col items-center justify-center w-16 h-14 rounded-full transition-all ${isActive ? 'bg-white/10 text-cyan-400' : 'text-white/50 hover:text-white/80 hover:bg-white/5'}`}
          >
            <div className={`mb-1 transition-transform ${isActive ? 'scale-110' : 'scale-100'}`}>
              {item.icon}
            </div>
            <span className="text-[9px] font-medium tracking-wider uppercase">{item.label}</span>
            {item.badge && item.badge > 0 ? (
              <span className="absolute top-1 right-2 bg-cyan-500 text-black text-[9px] font-bold w-3.5 h-3.5 rounded-full flex items-center justify-center">
                {item.badge}
              </span>
            ) : null}
          </button>
        );
      })}
    </div>
  );
};

const CartView = ({ cart, updateQuantity, removeFromCart, clearCart, setCurrentView }: { cart: CartItem[], updateQuantity: (id: string, delta: number) => void, removeFromCart: (id: string) => void, clearCart: () => void, setCurrentView: (v: string) => void }) => {
  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  
  const handleCheckout = () => {
    if (cart.length === 0) return;
    
    let text = `*New Order from BundlyPlus*\n\n`;
    cart.forEach(item => {
      text += `• ${item.quantity}x ${item.name} ($${item.price * item.quantity})\n`;
    });
    text += `\n*Total: $${total}*`;
    
    window.open(`https://wa.me/${siteSettings.whatsapp_number || ''}?text=${encodeURIComponent(text)}`, '_blank');
  };

  if (cart.length === 0) {
    return (
      <div className="pt-40 flex flex-col items-center justify-center text-white/50">
        <ShoppingCart size={48} className="mb-4 opacity-20" />
        <p className="mb-6">Your cart is empty</p>
        <button 
          onClick={() => setCurrentView('products')}
          className="px-6 py-2 rounded-full border border-white/20 text-white/80 hover:bg-white/10 text-sm font-medium uppercase tracking-widest transition-colors flex items-center gap-2"
        >
          <ArrowLeft size={16} /> Continue Shopping
        </button>
      </div>
    );
  }

  return (
    <section className="relative z-10 pt-10 pb-10 px-6 max-w-4xl mx-auto flex flex-col">
      <div className="flex justify-between items-center mb-10">
        <button 
          onClick={() => setCurrentView('products')}
          className="text-white/50 hover:text-white transition-colors flex items-center gap-2 text-sm uppercase tracking-widest"
        >
          <ArrowLeft size={16} /> Back
        </button>
        <h2 className="text-3xl font-serif text-white uppercase tracking-widest text-center">Your Cart</h2>
        <button 
          onClick={clearCart}
          className="text-red-400/70 hover:text-red-400 transition-colors flex items-center gap-2 text-sm uppercase tracking-widest"
        >
          Clear Cart
        </button>
      </div>
      
      <div className="space-y-4 mb-10">
        {cart.map((item, index) => (
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
            key={item.id} 
            className="bg-white/5 border border-white/10 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4"
          >
            <div className="flex-1 text-center sm:text-left">
              <h3 className="text-white font-medium">{item.name}</h3>
              <p className="text-white/50 text-xs">{item.duration?.toLowerCase().replace('_', ' ') || 'month'}</p>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center bg-white/5 rounded-full border border-white/10">
                <button onClick={() => updateQuantity(item.id, -1)} className="w-8 h-8 flex items-center justify-center text-white/70 hover:text-white transition-colors">
                  <Minus size={14} />
                </button>
                <span className="w-8 text-center text-sm font-medium">{item.quantity}</span>
                <button onClick={() => updateQuantity(item.id, 1)} className="w-8 h-8 flex items-center justify-center text-white/70 hover:text-white transition-colors">
                  <Plus size={14} />
                </button>
              </div>
              
              <div className="w-20 text-right font-serif text-lg">
                ${item.price * item.quantity}
              </div>
              
              <button onClick={() => removeFromCart(item.id)} className="w-8 h-8 flex items-center justify-center text-red-400/70 hover:text-red-400 hover:bg-red-400/10 rounded-full transition-colors">
                <Trash2 size={16} />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
      
      <div className="bg-white/5 border border-white/10 rounded-3xl p-6 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div>
          <p className="text-white/50 text-sm uppercase tracking-wider mb-1">Total Amount</p>
          <p className="text-4xl font-serif text-white">${total}</p>
        </div>
        <button 
          onClick={handleCheckout}
          className="w-full sm:w-auto px-8 py-4 rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-bold uppercase tracking-widest hover:opacity-90 transition-opacity"
        >
          Checkout via WhatsApp
        </button>
      </div>
    </section>
  );
};

const BundlesView = ({ addToCart }: { addToCart: (p: Bundle) => void }) => {
  if (bundlesData.length === 0) {
    return (
      <section className="relative z-10 pt-10 pb-10 px-6 max-w-6xl mx-auto flex flex-col items-center">
        <h2 className="text-3xl md:text-4xl font-serif text-white uppercase tracking-widest mb-8 text-center">Exclusive Bundles</h2>
        <div className="bg-white/5 border border-white/10 rounded-3xl p-12 text-center max-w-2xl w-full mt-10">
          <Layers size={48} className="mx-auto text-white/20 mb-6" />
          <h3 className="text-xl font-medium text-white mb-2">No Bundles Available Right Now</h3>
          <p className="text-white/50 text-sm mb-8">We are currently crafting some amazing money-saving bundles. Check back soon!</p>
          <button className="px-8 py-3 rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors text-sm font-medium">
            Notify Me
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="relative z-10 pt-10 pb-10 px-6 max-w-6xl mx-auto flex flex-col items-center">
      <h2 className="text-3xl md:text-4xl font-serif text-white uppercase tracking-widest mb-16 text-center">Exclusive Bundles</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 w-full">
        {bundlesData.map((bundle, index) => (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: index * 0.1 }}
            key={bundle.id} 
            className="bg-gradient-to-b from-white/10 to-white/5 backdrop-blur-md border border-white/20 rounded-3xl p-8 flex flex-col relative hover:from-white/15 hover:to-white/10 transition-all shadow-xl"
          >
            <div className="absolute -top-4 -right-4 bg-gradient-to-tr from-orange-400 to-pink-500 text-white text-[10px] uppercase tracking-widest font-bold px-4 py-2 rounded-full shadow-lg transform rotate-3">
              Save {Math.round(((bundle.originalPrice - bundle.price) / bundle.originalPrice) * 100)}%
            </div>
            
            <h3 className="text-2xl font-serif text-white mb-2">{bundle.name}</h3>
            <p className="text-white/60 text-sm mb-6 h-10">{bundle.description}</p>
            
            <div className="flex items-end gap-3 mb-8">
              <span className="text-5xl font-serif text-white">${bundle.price}</span>
              <div className="flex flex-col pb-1">
                <span className="text-white/40 line-through text-sm">${bundle.originalPrice}</span>
                <span className="text-white/60 text-xs">/{bundle.duration?.replace('_', ' ')}</span>
              </div>
            </div>
            
            <div className="space-y-4 mb-10 flex-grow">
              <p className="text-white/80 text-xs uppercase tracking-widest font-medium mb-4">What's Included:</p>
              {bundle.features.map((feature, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="mt-0.5 bg-cyan-400/20 p-1 rounded-full text-cyan-400">
                    <Check size={12} />
                  </div>
                  <span className="text-white/70 text-sm">{feature}</span>
                </div>
              ))}
            </div>
            
            <button 
              onClick={() => addToCart({ ...bundle, isBundle: true })}
              className="w-full py-4 rounded-full bg-white text-black font-bold uppercase tracking-widest hover:bg-white/90 transition-colors mt-auto"
            >
              Add Bundle to Cart
            </button>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

const SubscriptionsView = ({ addToCart }: { addToCart: (p: Product) => void }) => {
  const subs = productsData.filter(p => p.duration);
  const durations = Array.from(new Set(subs.map(p => p.duration)));

  return (
    <section className="relative z-10 pt-10 pb-10 px-6 max-w-6xl mx-auto flex flex-col items-center">
      <h2 className="text-3xl md:text-4xl font-serif text-white uppercase tracking-widest mb-16 text-center">Subscriptions</h2>
      
      {durations.map(duration => {
        const durationProducts = subs.filter(p => p.duration === duration);
        if (durationProducts.length === 0) return null;
        
        return (
          <div key={duration} className="w-full mb-16">
            <h3 className="text-xl font-medium text-white/80 mb-6 border-b border-white/10 pb-2">{duration} Plans</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 w-full">
              {durationProducts.map((product, index) => (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.05 }}
                  key={product.id} 
                  className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-6 flex flex-col items-center text-center relative hover:bg-white/10 transition-colors"
                >
                  <div className="w-full h-32 mb-4 rounded-2xl overflow-hidden bg-white/5 relative">
                    <img 
                      src={product.image_url || `https://picsum.photos/seed/${product.id}/400/300`} 
                      alt={product.name}
                      loading="lazy"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h4 className="text-white/90 uppercase tracking-widest text-sm font-medium mb-2">{product.name}</h4>
                  <p className="text-white/50 text-xs mb-4 h-10 overflow-hidden">{product.description}</p>
                  <div className="text-2xl text-white font-serif mb-6">${product.price}</div>
                  <button 
                    onClick={() => addToCart(product)}
                    className="w-full py-2.5 rounded-full border border-white/20 text-white/80 hover:bg-white/10 text-xs font-medium uppercase tracking-widest transition-colors mt-auto block text-center"
                  >
                    Subscribe
                  </button>
                </motion.div>
              ))}
            </div>
          </div>
        );
      })}
    </section>
  );
};

export default function App() {
  const [currentView, setCurrentView] = useState('home');
  const [cart, setCart] = useState<CartItem[]>([]);

  const addToCart = (product: Product | Bundle) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === productId) {
        const newQ = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQ };
      }
      return item;
    }));
  };

  const clearCart = () => setCart([]);

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white font-sans selection:bg-cyan-500/30 overflow-x-hidden">
      <Background />
      <Navbar cartCount={cartCount} setCurrentView={setCurrentView} />
      <main className="pt-20 pb-32">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentView}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            {currentView === 'home' && (
              <>
                <Hero />
                <WhyChooseUs />
                <Pricing addToCart={addToCart} />
                <Testimonials />
                <FAQ />
              </>
            )}
            {currentView === 'products' && <ProductsView addToCart={addToCart} />}
            {currentView === 'bundles' && <BundlesView addToCart={addToCart} />}
            {currentView === 'subscriptions' && <SubscriptionsView addToCart={addToCart} />}
            {currentView === 'cart' && (
              <CartView cart={cart} updateQuantity={updateQuantity} removeFromCart={removeFromCart} clearCart={clearCart} setCurrentView={setCurrentView} />
            )}
          </motion.div>
        </AnimatePresence>
      </main>
      <BottomNav currentView={currentView} setCurrentView={setCurrentView} cartCount={cartCount} />
    </div>
  );
}
