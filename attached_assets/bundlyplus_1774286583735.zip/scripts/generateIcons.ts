import * as geminiService from '../src/services/geminiService';
import fs from 'fs';
import path from 'path';
import 'dotenv/config';

if (!process.env.GEMINI_API_KEY) {
  console.error('GEMINI_API_KEY is not set');
  process.exit(1);
}

const products = JSON.parse(fs.readFileSync('./src/data/products.json', 'utf8'));

async function generateAllIcons() {
  for (const product of products.slice(0, 3)) {
    console.log(`Generating icon for ${product.name}...`);
    const iconUrl = await geminiService.generateProductIcon(product.name);
    if (iconUrl) {
      product.image_url = iconUrl;
      console.log(`Generated icon for ${product.name}`);
    }
  }
  fs.writeFileSync('./src/data/products.json', JSON.stringify(products, null, 2));
  console.log('Icons generated and saved to products.json');
}

generateAllIcons();
